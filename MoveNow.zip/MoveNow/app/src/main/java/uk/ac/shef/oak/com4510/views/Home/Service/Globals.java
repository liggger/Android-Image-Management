package uk.ac.shef.oak.com4510.views.Home.Service;

public class Globals {
    public static final String RESTART_INTENT = "uk.ac.shef.oak.restarter";
}
